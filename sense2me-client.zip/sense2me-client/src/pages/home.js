import React from "react";
import {Link} from "react-router-dom";

import NavBar from "../components/NavBar";
import Shop from "./shop";

function Home(){
    
    return(
        <NavBar />
    );

}

export default Home;