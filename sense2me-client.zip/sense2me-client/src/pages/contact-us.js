import React from "react";

import "./contact-us.css";

import NavBar from "../components/NavBar";

function ContactUs(){

    return(
        <div className="ContactUs">
            <NavBar/>
        </div>
    );

}

export default ContactUs;