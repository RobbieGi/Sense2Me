import React, {useEffect} from "react";

function CreateOrder(){

    useEffect(() => {
      const form = document.getElementById("create-order");
      form.addEventListener("submit", handleForm);
      return () => {
        form.removeEventListener("submit", handleForm);
      };
    }, []);
  
    function handleForm(event) {
      console.log("Clicked")
      event.preventDefault();
      
      const date = document.getElementById("date").value;
      const price = document.getElementById("price").value;
      const items = document.getElementById("items").value;
      const user = document.getElementById("user").value;
      const orderCode = document.getElementById("orderCode").value;
      const address = document.getElementById("address").value;
  
      // Validation 
      if (!date || !price || !items || !user || !orderCode || !address) {
        console.log("Validation")
        window.alert("All fields are required.");
        return;
      }

      const orderData = {
        date: date,
        price: price,
        items: items,
        orderCode: orderCode,
        dispatched: false,
        address: address,
      };
  
      console.log(orderData);
  
      fetch(process.env.REACT_APP_API + "/order", {
        mode: "cors",
        method: "POST",
        body: JSON.stringify(orderData),
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((response) => {
        if (response.ok) {
          return response.json();
        }
        throw new Error('Failed to create order');
      })
      .then((order) => {
        console.log('Created order:', order);
        // Handle success and perform necessary actions
      })
      .catch((error) => {
        console.error('Error creating order:', error);
        // Handle error and display appropriate message to the user
      });
    }
  
      return(
          <div className="CreateAdmin">
              <div className="content-main">
                <form id="create-order">
                  <label>Date:</label>
                  <input type="text" id="date" placeholder="Date" className="text-input"/>
                  <label>Price:</label>
                  <input type="text" id="price" placeholder="Price" className="text-input"/>
                  <label>Items:</label>
                  <input type="text" id="items" placeholder="Items" className="text-input"/>
                  <label>User:</label>
                  <input type="text" id="user" placeholder="user" className="text-input"/>
                  <label>Order Code:</label>
                  <input type="text" id="orderCode" placeholder="OrderCode" className="text-input"/>
                  <label>Address:</label>
                  <input type="text" id="address" placeholder="Address" className="text-input"/>
                  <button type="submit">Create</button>
              </form>
            </div>
          </div>
      );
  
  }
  
  export default CreateOrder;