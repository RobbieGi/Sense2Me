import React, { useEffect, useState } from "react";

import "./UpdateProduct.css"

function UpdateProduct(){

    let i = 0;
    const [product, setProduct] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        fetch(process.env.REACT_APP_API + "/product")
        .then(res => {
            if (!res.ok){
                throw new Error("Request failed with status: " + res.status);
            }
            return res.json();
        })
        .then(data => {
            console.log(data);
            setProduct(data.map((product) => ({ ...product })));
            console.log(product[i].amount);
        })
        .catch(error => {
            console.error("Error: " + error)
        })
    }, [])

    useEffect(() => {
        if (product.length > 0) {
          document.getElementById("name").value = product[i].name;
          document.getElementById("price").value = product[i].price;
          document.getElementById("description").value = product[i].description;
          document.getElementById("image").value = product[i].image;
          document.getElementById("amount").value = product[i].amount;
        }
      }, [product, i]);

      useEffect(() => {
        if (product.length > 0) {
          updateFormValues(currentIndex);
        }
      }, [product, currentIndex]);
    
      function updateFormValues(index) {
        document.getElementById("name").value = product[index].name;
        document.getElementById("price").value = product[index].price;
        document.getElementById("description").value = product[index].description;
        document.getElementById("image").value = product[index].image;
        document.getElementById("amount").value = product[index].amount;
      }
    
      function changeLeft() {
        if (currentIndex === 0) {
          alert("No More Records");
        } else {
          setCurrentIndex(currentIndex - 1);
        }
      }
    
      function changeRight() {
        if (currentIndex === product.length - 1) {
          alert("No More Records");
        } else {
          setCurrentIndex(currentIndex + 1);
        }
      }

      useEffect(() => {
        const form = document.getElementById("product-form");
        form.addEventListener("submit", handleForm);
        return () => {
          form.removeEventListener("submit", handleForm);
        };
      }, []);

      function handleForm(event) {
        event.preventDefault();
        
        const name = document.getElementById("name").value;
        const price = document.getElementById("price").value;
        const description = document.getElementById("description").value;
        const image = document.getElementById("image").value;
        const amount = document.getElementById("amount").value;

        console.log(amount)

        fetch(process.env.REACT_APP_API + '/product/'  +encodeURIComponent(name), {
          mode: "cors", 
          method:"PUT",
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: name, 
            price: price, 
            description: description,
            image: image,
            amount: amount,
          })
        })
            .then(response => {
                if (response.ok) {
                  return response.json();
                }
                throw new Error('Failed to replace product');
              })
        .then(data => {
          window.alert("Product Replaced");
          document.getElementById("product-form").reset();
        })
        .catch(error => {
          console.error('Error replacing product:', error);
        });
      }

    return(
        <div className="AddProduct">
          <div className="content-main">
            <div className="container">
                <form id="product-form">
                    <label>Update Product</label>
                    <label>Product Name:</label>
                    <input type="text" id="name" placeholder="product-name" className="text-input"/>
                    <label>Product Price:</label>
                    <input type="text" id="price" placeholder="product-price" className="text-input"/>
                    <label>Product Description:</label>
                    <input type="text" id="description" placeholder="product-description" className="text-input"/>
                    <label>Product Image Link:</label>
                    <input type="text" id="image" placeholder="product-image" className="text-input"/>
                    <label>Amount of Products:</label>
                    <input type="number" id="amount" placeholder="product-amount" className="text-input" min="1"/>
                    <button type="submit">Update Product</button>
                </form>
                <button className="movementBtns" onClick={changeLeft}>Backwards</button>
                <button className="movementBtns" onClick={changeRight}>Forwards</button>
            </div>
          </div>
        </div>
      );

}

export default UpdateProduct;